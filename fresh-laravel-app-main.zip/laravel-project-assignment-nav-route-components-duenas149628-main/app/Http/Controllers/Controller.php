<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    // Task 4: Save to Database
    public function store(Request $request)
    {
        $validated = $request->validate([
            'first_name'     => 'required|string|max:255',
            'last_name'      => 'required|string|max:255',
            'middle_name'    => 'nullable|string|max:255',
            'nickname'       => 'required|string|max:255',
            'email'          => 'required|email|unique:users,email',
            'age'            => 'required|integer|min:1',
            'address'        => 'required|string',
            'contact_number' => 'required|string|max:20',
        ]);

        User::create($validated);

        return redirect()->route('users.index')->with('success', 'User registered successfully!');
    }

    // Task 5: Display List
    public function index()
    {
        $users = User::all();
        return view('user_list', compact('users'));
    }

    // Task 6: Delete Function
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('users.index')->with('success', 'User deleted successfully!');
    }

    // Task 7: Show Edit Form
    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('user_edit', compact('user'));
    }

    // Task 7: Save Changes
    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'first_name'     => 'required|string|max:255',
            'last_name'      => 'required|string|max:255',
            'middle_name'    => 'nullable|string|max:255',
            'nickname'       => 'required|string|max:255',
            'email'          => 'required|email|unique:users,email,' . $id,
            'age'            => 'required|integer',
            'address'        => 'required|string',
            'contact_number' => 'required|string',
        ]);

        $user->update($validated);

        return redirect()->route('users.index')->with('success', 'User updated successfully!');
    }
}