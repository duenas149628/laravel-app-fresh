<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User List</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100 p-10">
    <div class="max-w-6xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800">Registered Users</h2>
            <a href="{{ route('users.register') }}" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Add New User</a>
        </div>

        @if(session('success'))
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-200">
                    <th class="p-3 border">Name</th>
                    <th class="p-3 border">Nickname</th>
                    <th class="p-3 border">Email</th>
                    <th class="p-3 border">Age</th>
                    <th class="p-3 border">Contact</th>
                    <th class="p-3 border text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($users as $user)
                <tr class="hover:bg-gray-50">
                    <td class="p-3 border">{{ $user->first_name }} {{ $user->last_name }}</td>
                    <td class="p-3 border">{{ $user->nickname }}</td>
                    <td class="p-3 border">{{ $user->email }}</td>
                    <td class="p-3 border">{{ $user->age }}</td>
                    <td class="p-3 border">{{ $user->contact_number }}</td>
                    <td class="p-3 border text-center">
                        <span class="text-gray-400 text-sm">Pending Task 6/7</span>
                    </td>
                    <td class="p-3 border text-center">
    <div class="flex justify-center space-x-2">
        <a href="#" class="text-blue-600 hover:text-blue-900">Edit</a>

        <form action="{{ route('users.destroy', $user->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this user?')">
            @csrf
            @method('DELETE')
            <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
        </form>
    </div>
</td>
                    
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>