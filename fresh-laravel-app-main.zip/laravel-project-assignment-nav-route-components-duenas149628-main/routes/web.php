<?php

use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


// --- NAVIGATION & STATIC PAGES ---
Route::get('/', function () {
    $emails = session()->get('emails', []);
    return view('welcome', ['emails' => $emails]);
});

Route::get('/about', function () { return view('about'); });
Route::get('/contact', function () { return view('contact'); });
Route::get('/services', function () { return view('services'); });
Route::get('/showcases', function () { return view('showcases'); });
Route::get('/blog', function () { return view('blog'); });


// --- ACTIVITY 2: SESSION EMAIL STORAGE ---
Route::post('/submit-email', function (Request $request) {
    $request->validate(['email' => 'required|email']);

    $newEmail = $request->input('email');
    $emails = session()->get('emails', []);

    if (in_array($newEmail, $emails)) {
        return back()->with('error', 'That email is already in the list!');
    }

    if (count($emails) >= 5) {
        return back()->with('error', 'Limit reached! You can only store 5 emails.');
    }

    $emails[] = $newEmail;
    session(['emails' => $emails]);

    return back()->with('success', 'Email added successfully!');
});

Route::post('/delete-email/{index}', function ($index) {
    $emails = session()->get('emails', []);
    if (isset($emails[$index])) {
        unset($emails[$index]);
        session(['emails' => array_values($emails)]);
    }
    return back()->with('success', 'Email removed successfully!');
});


// --- ACTIVITY 3: DATABASE CRUD (USER REGISTRATION) ---

// Task 3: Show Registration Form
Route::get('/register', function () {
    return view('user_registration');
})->name('users.register');

// Task 4: Store User in Database
Route::post('/users/store', [UserController::class, 'store'])->name('users.store');

// Task 5: Display User List
Route::get('/users', [UserController::class, 'index'])->name('users.index');

// Task 6: Delete User
Route::delete('/users/{id}', [UserController::class, 'destroy'])->name('users.destroy');

// Task 7: Update Function (Edit form and Update logic)
Route::get('/users/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
Route::put('/users/{id}', [UserController::class, 'update'])->name('users.update');